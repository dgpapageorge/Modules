# Ketsu/Zetsu Phone Test Results

Fill this in after testing the numbered modules inside Ketsu/Zetsu.

- Device:
- App and version:
- Date tested:
- Network/Wi-Fi:
- phone-pack.zip SHA-256: see phone-pack.zip.sha256

| # | Module file | Module | Type | Import | Main/Search | Info/Details | Content/Playback | Notes |
|---|---|---|---|---|---|---|---|---|
| 1 | 01_Text_Royal_Road.txt | Royal Road | Text |  |  |  |  |  |
| 2 | 02_Text_NovelFire.txt | NovelFire | Text |  |  |  |  |  |
| 3 | 03_Text_Scribble_Hub.txt | Scribble Hub | Text |  |  |  |  |  |
| 4 | 04_Text_NovelBin.txt | NovelBin | Text |  |  |  |  |  |
| 5 | 05_Image_MangaDex.txt | MangaDex | Image |  |  |  |  |  |
| 6 | 06_Image_Mangapill.txt | Mangapill | Image |  |  |  |  |  |
| 7 | 07_Image_WeebCentral.txt | WeebCentral | Image |  |  |  |  |  |
| 8 | 08_Image_WEBTOON.txt | WEBTOON | Image |  |  |  |  |  |
| 9 | 09_Video_AniLiberty.txt | AniLiberty | Video |  |  |  |  |  |
| 10 | 10_Video_Internet_Archive_Anime.txt | Internet Archive Anime | Video |  |  |  |  |  |
| 11 | 11_Video_Wikimedia_Commons_Anime.txt | Wikimedia Commons Anime | Video |  |  |  |  |  |
| 12 | 12_Video_PeerTube_Anime.txt | PeerTube Anime | Video |  |  |  |  |  |
| 13 | 13_Text_Baka-Tsuki.txt | Baka-Tsuki | Text |  |  |  |  |  |
| 14 | 14_Text_FreeWebNovel.txt | FreeWebNovel | Text |  |  |  |  |  |
| 15 | 15_Text_ReadNovelFull.txt | ReadNovelFull | Text |  |  |  |  |  |
| 16 | 16_Text_Novgo.txt | Novgo | Text |  |  |  |  |  |
| 17 | 17_Text_NovelCool.txt | NovelCool | Text |  |  |  |  |  |
| 18 | 18_Text_WuxiaWorld.txt | WuxiaWorld | Text |  |  |  |  |  |
| 19 | 19_Image_Asura_Scans.txt | Asura Scans | Image |  |  |  |  |  |
| 20 | 20_Image_MangaKatana.txt | MangaKatana | Image |  |  |  |  |  |
| 21 | 21_Image_Tapas.txt | Tapas | Image |  |  |  |  |  |
| 22 | 22_Video_Internet_Archive_TV_Movies.txt | Internet Archive TV & Movies | Video |  |  |  |  |  |
| 23 | 23_Video_Wikimedia_Commons_Video.txt | Wikimedia Commons Video | Video |  |  |  |  |  |
| 24 | 24_Video_PeerTube_Movies_Shows.txt | PeerTube Movies & Shows | Video |  |  |  |  |  |
| 25 | 25_Video_Internet_Archive_Feature_Films.txt | Internet Archive Feature Films | Video |  |  |  |  |  |
| 26 | 26_Video_Internet_Archive_Classic_TV.txt | Internet Archive Classic TV | Video |  |  |  |  |  |
| 27 | 27_Video_Pluto_TV_Live.txt | Pluto TV Live | Video |  |  |  |  |  |

Use PASS, FAIL, or SKIP in the result columns.
For any FAIL, include the app error text, the action that failed, and whether retrying changed the result.
The goal is complete only when every module imports and its content/playback check passes on the phone.
